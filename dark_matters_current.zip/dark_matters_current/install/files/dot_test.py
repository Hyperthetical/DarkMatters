from numpy import *

m = array([[3.0,4.0,5.0],[2.0,6.0,7.0]])
v = array([0.0,1.0,0.0])
print(m.shape[1])
print(dot(m,v))
