import sys
import numpy as np

def get_col_list(list2d,col):
    data = []
    for row in list2d:
        data.append(row[col])
    return data

def get_col(list2d,col):
    try:
        matrix = np.array(list2d,dtype=float)
    except TypeError:
        print("get_col: data in "+matrix+" not all float types")
        sys.exit(2)
    try:
        #print(matrix.shape)
        v = np.zeros(matrix.shape[1])
    except IndexError:
        print("get_col: first input needs to be at least 2 dimensional")
        sys.exit(2)
    v[col] = 1.0
    return np.dot(matrix,v)

def loadFile(fname,suppress_output=False,dataArray=True,comment="#"):
    lines = []
    try:
        inf = open(fname,"r")
    except:
        if not suppress_output:
            print("loadFile: file: "+"'"+fname+"'"+" could not be opened")
        return []
    for l in inf:
        if(not l.strip().startswith(comment)):
            if comment in l.strip():
                lines.append(l.strip()[:l.strip().index(comment)])
            else:
                lines.append(l.strip())
    inf.close()
    if dataArray:
        n = len(lines[0].split())
        farr = np.zeros((len(lines),n))
        for i in range(0,len(lines)):
            s = lines[i].split()
            for j in range(0,n):
                try:
                    farr[i][j] = float(s[j])
                except:
                    try:
                        farr[i][j] = float(s[j].strip(","))
                    except:
                        print("loadFile: entry: "+"'"+s[j].strip(",")+"'"+" in file: "+"'"+fname+"'"+" could not be converted to a floating point number")
                        #sys.exit(2)
    else:
        farr = []
        for l in lines:
            s = l.split()
            farr.append(s)
    return farr

