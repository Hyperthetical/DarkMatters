from .files import loadFile,get_col 
